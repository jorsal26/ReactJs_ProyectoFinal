
function Main() {
  return (
    <main>
      <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Cum, voluptatibus facere, harum neque molestiae consectetur maxime ipsa eaque aperiam omnis adipisci quam accusamus? Optio esse distinctio placeat neque quam iusto.</p>
      <p>Lorem ipsum, dolor sit amet consectetur adipisicing elit. Facere natus esse numquam nihil dignissimos eligendi, vel saepe pariatur aut voluptatum, ut excepturi eius doloremque exercitationem dolores cumque? Odit, saepe tempore?</p>
       
    </main>
  )
}

export default Main