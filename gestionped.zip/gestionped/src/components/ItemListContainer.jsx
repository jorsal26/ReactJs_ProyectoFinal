function ItemLisContainer(props) {
    return (
        <>
        <h2>{props.greeting}</h2>
        </>
    )
}

export default ItemLisContainer
